package perun_deaddrop;
import java.util.Scanner;
public class EvenEntryLoop 
{
	// initialize variables
	static int inputnumber = 0;
	static boolean repeat = false;
	static boolean end = false;
	private static Scanner triglav;
	public static void main(String[] args)
	{
	// Initialize scanner
	triglav = new Scanner(System.in);
	// begin prompt
	do
	{
		System.out.println("Please input a number: ");
		inputnumber = triglav.nextInt();
		boolean svarog = isEven(inputnumber);
		boolean end = (inputnumber == 999);
		if (end == true)
		{
			// sentinel number is 999, which will force the program to abort.
			System.exit(0);
		}
		else if (svarog == true)
		{
			System.out.println("Good job!");
			repeat = true;
		}
		else if (svarog == false)
		{
			System.out.println(inputnumber + " is not a even number.");
			repeat = true;
		}
	}
	while (repeat == true);
	}
	 public static boolean isEven(int number)
	   {
	     int alpha = number % 2;
	     boolean beta = (alpha == 0);
	     return beta;
	   }
}
