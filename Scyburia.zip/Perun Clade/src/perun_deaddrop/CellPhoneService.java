package perun_deaddrop;
import java.util.Scanner;
public class CellPhoneService
{
	   private static Scanner Triglav;
	   private static Scanner Perun;
	   private static Scanner Svarog;
	   public static void main (String args[])
	   {
	      // declare variables here
	      int TalkMinutes = 1;
	      int TextMessages = 1;
	      int DataUsed = 1;
	      boolean PlanA = false;
	      boolean PlanB = false;
	      boolean PlanC = false;
	      boolean PlanD = false;
	      boolean PlanE = false;
	      boolean PlanF = false;
	      Triglav = new Scanner(System.in);
	      Perun = new Scanner (System.in);
	      Svarog = new Scanner (System.in);
	      // prompt user to enter talk minutes needed here
	        System.out.println("Please enter the maximum amount of talk minutes you use on a monthly basis: ");
	       TalkMinutes = Triglav.nextInt();
	      // prompt user to enter text messages needed here
	        System.out.println("Please enter the maximum amount of text messages you use on a monthly basis: ");
	       TextMessages = Perun.nextInt();
	      // prompt user to enter gigabytes of data needed here
	        System.out.println("Please enter the maximum amount of data in gigabytes you use on a monthly basis: ");
	       DataUsed = Svarog.nextInt();
	      // add program logic here
	       if (DataUsed <= 0)
	       {
	           if (TalkMinutes >= 500)
	           {
	               if ((TextMessages >= 0) && (TextMessages < 100))
	               {
	            	   PlanC = true;
	               }
	               else
	               {
	            	   PlanD = true;
	               }
	           }
	           else if (TalkMinutes <= 500)
	           {
	               if (TextMessages > 0)
	               {
	                   PlanB = true;
	               }
	               else if (TextMessages <= 0)
	               {
	                   PlanA = true;
	               }
	           }
	       }
	       else
	       {
	           if ((DataUsed > 0) && (DataUsed < 2))
	           {
	        	   PlanE = true;
	           }
	           else
	           {
	        	   PlanF = true;
	           }
	       }
	      // output recommended plan here
	       if (PlanE == true)
	       {
	           System.out.println("The best plan for you would be Plan E for up to 2 gigabytes for $79 per month.");
	       }
	       else if (PlanF == true)
	       {
	    	   System.out.println("The best plan for you would be Plan F for up to 2 gigabytes or more for $87 per month.");
	       }
	       else if (PlanC == true)
	       {
	           System.out.println("The best plans for you would be either Plan C for up to 100 text messages for $61 per month.");
	       }
	       else if (PlanA == true)
	       {
	           System.out.println("The best plan for you would be Plan A for up to 500 minutes of talk for $49 per month.");
	       }
	       else if (PlanB == true)
	       {
	           System.out.println("The best plan for you would be Plan B for up to 500 minutes of talk with text for $55 per month.");
	       }
	       else if (PlanD == true)
	       {
	           System.out.println("The best plan for you would be Plan D for up to 100 text messages with 500 or more minutes of talk for $70 per month.");
	       }
	   }
	}