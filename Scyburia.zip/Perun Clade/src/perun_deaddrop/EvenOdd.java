package perun_deaddrop;
import java.util.Scanner;
class EvenOdd
{
   private static Scanner triglav;
public static void main(String[] args) 
   {
      int UserInput;
      triglav = new Scanner(System.in);
      System.out.println("Please enter a valid integer: ");
      UserInput = triglav.nextInt();
      boolean gamma = isEven(UserInput);
      if (gamma == true)
      {
          System.out.println("The integer is even.");
      }
      else
      {
          System.out.println("the integer is odd.");
      }
   }
   public static boolean isEven(int number)
   {
     int alpha = number % 2;
     boolean beta = (alpha == 0);
     return beta;
   }
}
