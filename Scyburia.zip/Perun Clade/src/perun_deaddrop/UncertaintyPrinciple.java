package perun_deaddrop;
import java.util.Scanner;
public class UncertaintyPrinciple 
{
	private static Scanner Veles;
	public static void main(String[] args)
	{
		Veles = new Scanner(System.in);
		int UncertaintyFactor1 = 1;
		int UncertaintyFactor2 = 5000;
		int Result = 0;
		int IntendedFactor = 0;
		int AttemptsMade = 0;
		System.out.println("Please specify the result you wish to achieve under the Uncertainty Principle: ");
		IntendedFactor = Veles.nextInt();
		while (Result != IntendedFactor)
		{
			// Random number is to be generated, will not halt until Result equals the intended factor.
			Result = (int) (Math.random() * ((UncertaintyFactor2 - UncertaintyFactor1)+1))+ UncertaintyFactor1;
			// Attempts made
			AttemptsMade = AttemptsMade + 1;
			System.out.println("Attempt " + AttemptsMade + ", Result is " + Result + ".");
		}
		System.out.println("Result " + Result + " has been reached. " + AttemptsMade + " attempts have been made in order to achieve the desired result.");
	}
}
