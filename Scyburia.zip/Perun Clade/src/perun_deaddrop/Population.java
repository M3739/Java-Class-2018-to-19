package perun_deaddrop;
public class Population 
{
	//initialize variables
	static double USpop = 315.0;
	static double Mexpop = 121.0;
	static double USdecay = 0.9985;
	static double Mexgrowth = 1.01;
	static int years = 0;
	//begin main method
	public static void main(String[] args)
	{
		//Begin logic
		while (USpop >= Mexpop)
		{
			USpop = USpop * USdecay;
			Mexpop = Mexpop * Mexgrowth;
			years++;
			System.out.println(years + " years, population of countries: United States: " + USpop + " Mexico: " + Mexpop);
		}
		System.out.println("It will take " + years + " years for Mexico's population to surpass the United State's population.");
		System.out.println(USpop + " " + Mexpop);
	}
}
